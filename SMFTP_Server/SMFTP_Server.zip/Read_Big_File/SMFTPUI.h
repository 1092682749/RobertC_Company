#pragma once

void print_UI_Welcome();
