#include "pch.h"
#include "SocketUntils.h"


SocketUntils::SocketUntils()
{
}


SocketUntils::~SocketUntils()
{
}
