#pragma once
#define SMFTP_PUT "put"
#define SMFTP_GET "get"
#define SMFTP_EXIT "ext"